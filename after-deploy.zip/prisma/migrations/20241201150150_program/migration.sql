/*
  Warnings:

  - You are about to drop the column `thumnail` on the `program` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "program" DROP COLUMN "thumnail";
