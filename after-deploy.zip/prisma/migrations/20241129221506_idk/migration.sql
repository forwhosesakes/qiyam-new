-- AlterTable
ALTER TABLE "category" ALTER COLUMN "updatedAt" DROP DEFAULT;
