-- AlterTable
ALTER TABLE "program" ADD COLUMN     "image" TEXT;
