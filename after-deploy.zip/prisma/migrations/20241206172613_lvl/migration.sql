-- AlterTable
ALTER TABLE "user" ALTER COLUMN "level" SET DEFAULT 'LEVEL_1';
