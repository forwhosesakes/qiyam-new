
const Messages = ()=>{
    return <section className="pt-48 px-12 min-h-screen">
        <button
         className="button p-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700"
        >اضافة مقرر </button>

    </section>
}

export default Messages