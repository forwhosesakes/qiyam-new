// import { StrictMode } from "react";
// import { createRoot } from "react-dom/client";
// import User4 from "./user4";

// createRoot(document.getElementById("app") as HTMLElement).render(
//   <StrictMode>
//     <User4 />
//   </StrictMode>,
// );