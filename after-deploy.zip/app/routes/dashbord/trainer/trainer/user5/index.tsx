// import { StrictMode } from "react";
// import { createRoot } from "react-dom/client";
// import User5 from "./user5";

// createRoot(document.getElementById("app") as HTMLElement).render(
//   <StrictMode>
//     <User5 />
//   </StrictMode>,
// );