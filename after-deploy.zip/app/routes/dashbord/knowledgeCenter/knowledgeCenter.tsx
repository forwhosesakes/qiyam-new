import { Section1 } from "./knowledgecenter/section1"
import Section2 from "./knowledgecenter/section2"

export const knowledgeCenter = (): JSX.Element => {
return (
  <div>
<Section1/>
<Section2/>

  </div>
)
}