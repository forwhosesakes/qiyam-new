export { knowledgeCenter } from "./knowledgeCenter";
